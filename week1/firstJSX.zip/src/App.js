import logo from './logo.svg';
import './App.css';
import React from 'react'

function App() {
  return (
    <>
        <h1>Heya Scotty</h1>
        <div className = "container">
          <h2>Things I need To Do:</h2>
          <ul>
            <li>Learn React ASAP</li>
            <li>Feed Peaches And Radar</li>
            <li>Work on Prog Pipe Services Website</li>
            <li>Get a Pizza</li>
          </ul>
        </div>
    </>

  )

}

export default App;
